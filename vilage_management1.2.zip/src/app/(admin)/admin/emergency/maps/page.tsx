export default function Page() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">แผนที่ฉุกเฉิน</h1>
      <div className="bg-white rounded-xl border border-gray-200 p-8">
        <p className="text-gray-500 text-center">หน้าแผนที่ฉุกเฉิน</p>
      </div>
    </div>
  );
}
