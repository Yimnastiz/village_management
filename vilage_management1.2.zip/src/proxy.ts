import { NextRequest, NextResponse } from "next/server";
import {
  getAuthenticatedAccessRedirectPath,
  getResidentAreaAccessInfo,
  getSessionContextFromRequest,
  isAdminUser,
  isSuperAdminUser,
} from "@/lib/access-control";

export async function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const session = await getSessionContextFromRequest(request);

  if (pathname.startsWith("/resident")) {
    if (!session) {
      const loginUrl = new URL("/auth/login", request.url);
      loginUrl.searchParams.set("callbackUrl", pathname);
      return NextResponse.redirect(loginUrl);
    }

    if (isSuperAdminUser(session)) {
      return NextResponse.redirect(new URL("/superadmin/dashboard", request.url));
    }

    const residentAccess = await getResidentAreaAccessInfo(session);
    if (!residentAccess.canAccess) {
      const isBindingRoute = pathname.startsWith("/resident/binding");
      if (!isBindingRoute) {
        return NextResponse.redirect(new URL(residentAccess.redirectPath, request.url));
      }
    }
  }

  if (pathname.startsWith("/admin")) {
    if (!session) {
      const loginUrl = new URL("/auth/login", request.url);
      loginUrl.searchParams.set("callbackUrl", pathname);
      return NextResponse.redirect(loginUrl);
    }

    const redirectPath = await getAuthenticatedAccessRedirectPath(session);
    if (!isAdminUser(session)) {
      return NextResponse.redirect(new URL(redirectPath, request.url));
    }
  }

  if (pathname.startsWith("/superadmin")) {
    if (!session) {
      const loginUrl = new URL("/auth/login", request.url);
      loginUrl.searchParams.set("callbackUrl", pathname);
      return NextResponse.redirect(loginUrl);
    }

    if (!isSuperAdminUser(session)) {
      const redirectPath = await getAuthenticatedAccessRedirectPath(session);
      return NextResponse.redirect(new URL(redirectPath, request.url));
    }
  }

  if (pathname === "/auth/register" && session) {
    return NextResponse.redirect(new URL("/auth/landing", request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    "/resident/:path*",
    "/admin/:path*",
    "/superadmin/:path*",
    "/auth/register",
  ],
};
